
from flask import Flask, request, render_template
from application.models import products,Users, Admin,UserOrders, PManager
from application.database import db
from application.config import LocalDevelopmentConfig
import os


app = Flask(__name__)


def create_app():
 app=Flask(__name__, template_folder="templates")
 #configuration
 app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
 
 if(os.getenv("ENV","development")=="production"):
  raise Exception ("currently no production config is setup..")
 else:
  app.config.from_object(LocalDevelopmentConfig) 
 db.init_app(app)
 #cel_app = create_celery_app(app)
 app.app_context().push()
 #return app,cel_app
 return app
 

#app,cel_app=create_app()
app=create_app()


import datetime
from io import StringIO
import csv
from celery.schedules import crontab
from jinja2 import Template
from email.mime.text import MIMEText #text msg in mail
from email.mime.multipart import MIMEMultipart # body have multiple part
from email.mime.base import MIMEBase
import pdfkit
from email import encoders
import smtplib # SMTP (Simple Mail Transfer Protocol) server to handle email communication

sender_email = "211000414@gmail.com"
password = "iitm" 

to="adarsh@gmail.com"
subject="greet msg from 211000414"
body="Hii dear, how are you"

SMTB_SERVER_HOST="localhost"
SMTB_SERVER_PORT=1025
 
def send_mail(to ,subject, body):
    msg = MIMEMultipart()
    msg["To"]=to
    msg["From"]=sender_email
    msg["Subject"]=subject
    msg.attach(MIMEText(body,"html"))

    server=smtplib.SMTP(host=SMTB_SERVER_HOST,port=SMTB_SERVER_PORT)
    server.login(user=sender_email,password=password)
    server.send_message(msg)
    server.quit()






def setup_periodic_tasks(sender, **kwargs):
    #sender.add_periodic_task(crontab(minute=0,hour=0), daily_reminder.s())
    sender.add_periodic_task(crontab(minute=40,hour=12,day_of_month=18), monthly_reminder.s())
    #sender.add_periodic_task(10, monthly_reminder.s())



def monthly_reminder():
    with app.app_context():
        admin = Users.query.all()
        items= products.query.all()
    rows=[]
    for item in items:  
        row = [
             item.product_name,
             item.category,
             item.unit,
             str(item.rate_per_unit)+" INR",
             str(item.quantity)+" unit"]
        rows.append(row)
    with open ("templates/report.html") as file:
        template=Template(file.read())
        month=datetime.date.today().strftime("%B")
        result=template.render(items=rows, month=month)

    message= MIMEMultipart()
    message["From"]=sender_email
    message["To"]=to
    message["Subject"]="Monthly report Ananlysis.."
    html_report= MIMEText(result,"html")
    html_report.add_header("Content-Disposition", f"attachment; filename={month}.html")
    message.attach(html_report)


    # content= pdfkit.from_string(result, False)
    # pdf_report = MIMEBase("application", "octet-stream")
    # pdf_report.set_payload(content)
    # encoders.encode_base64(pdf_report)
    # pdf_report.add_header("Content-Disposition", f"attachment; filename={month}.pdf")
    # message.attach(pdf_report)
    
    server=smtplib.SMTP(host=SMTB_SERVER_HOST,port=SMTB_SERVER_PORT)
    server.login(user=sender_email,password=password)
    server.send_message(message)
    server.quit()

    
#monthly_reminder()

def monthly_reminder1():
    with app.app_context():
        admin = Users.query.all()
        items= products.query.all()
    rows=[]
    for item in items:  
        row = [
             item.product_name,
             item.category,
             item.unit,
             str(item.rate_per_unit)+" INR",
             str(item.quantity)+" unit"]
        rows.append(row)
    with open ("templates/report.html") as file:
        template=Template(file.read())
        month=datetime.date.today().strftime("%B")
        result=template.render(items=rows, month=month)

    message= MIMEMultipart()
    message["From"]=sender_email
    message["To"]=to
    message["Subject"]="Monthly report Ananlysis.."
    html_report= MIMEText(result,"html")
    html_report.add_header("Content-Disposition", f"attachment; filename={month}.html")
    message.attach(html_report)


    content= pdfkit.from_string(result, False)
    pdf_report = MIMEBase("application", "octet-stream")
    pdf_report.set_payload(content)
    encoders.encode_base64(pdf_report)
    pdf_report.add_header("Content-Disposition", f"attachment; filename={month}.pdf")
    message.attach(pdf_report)
    
    # server=smtplib.SMTP(host=SMTB_SERVER_HOST,port=SMTB_SERVER_PORT)
    # server.login(user=sender_email,password=password)
    # server.send_message(message)
    # server.quit()



if __name__ =='__main__':
    # run i you directly call "python myreminder.py"
    #send_mail(to,"Greet message","Mailhock is working successully...Thanks")
    monthly_reminder1()
    pass