# python main.py
import pandas as pd
import os
import cgi
from flask import Flask, request, jsonify, session
from flask_restful import Api, Resource 
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from io import StringIO

import json
import time
import csv
import jwt

import datetime
from functools import wraps
import jwt
your_secret_key="IamstudentofIITMBS123"

from flask import Flask, request, render_template,make_response
from flask import current_app as app
from application.models import products,Users, Admin,UserOrders, PManager
from application.database import db

from application.models import products, Users,Admin, UserOrders
from application.database import db
from application.config import LocalDevelopmentConfig
#initialization
from flask import Flask
from flask_caching import Cache
from flask_cors import CORS

#celery
from worker import create_celery_app ,cel_app
from cache import cache
from celery.result import AsyncResult

app = Flask(__name__)


# Enable CORS for all routes with the necessary options
CORS(app, resources={r"/*": {"origins": "http://localhost:8080"}}, supports_credentials=True, methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])

#tasks
from task import product_csv,msg
import task


def create_app():
 app=Flask(__name__, template_folder="templates")
 #configuration
 app.config["CACHE_TYPE"] = "redis"
 app.config["CACHE_DEFAULT_TIMEOUT"] = 30
 app.config["CACHE_REDIS_URL"] = "redis://localhost:6379/2"
 app.config['SECRET_KEY'] = 'your-secret-key'
 app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
 app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
 app.config['CORS_HEADERS'] = ['Content-Type', 'Access-Control-Allow-Origin', 'Access-Control-Allow-Methods', 'Access-Control-Allow-Headers', 'Access-Control-Allow-Credentials']

 if(os.getenv("ENV","development")=="production"):
  raise Exception ("currently no production config is setup..")
 else:
  app.config.from_object(LocalDevelopmentConfig) 
 db.init_app(app)
 #cel_app = create_celery_app(app)
 cache.init_app(app)
 app.app_context().push()
 #return app,cel_app
 return app
 

#app,cel_app=create_app()
app=create_app()
cache = Cache(app, config={'CACHE_TYPE': 'redis', 'CACHE_REDIS_URL': 'redis://localhost:6379/0'})

# cel_app=create_celery_app(app)
def resp(data, status_code):
  # note: data={x:1,y:2}
  response = jsonify(data)
  response.headers.add("Access-Control-Allow-Origin", "http://localhost:8080")
  response.headers.add("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
  response.headers.add("Access-Control-Allow-Headers", "Content-Type")
  response.headers.add("Access-Control-Allow-Credentials", "true")  # Allow credentials
  response.status_code=status_code
  return response


@app.route('/user_export_csv', methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def user_export_csv():
    if request.method=="POST":
      result= task.user_csv.delay()
      vue_data={"msg":result.id}
      resp1=resp(vue_data,200)
      return resp1
    return  resp({"msg":"options method is reading"}, 200)


@app.route('/user_download_csv', methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def user_download_csv():
    if request.method=="POST":
      id=request.json.get("id")
      result=AsyncResult(id)
      vue_data={"msg":result.result}  
      resp1=resp(vue_data,200)
      return resp1
    return resp({"msg":"options method is reading"}, 200)
#CSV FILE
@app.route('/product_export_csv', methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def product_export_csv():
    if request.method=="POST":
      result= task.product_csv.delay()
      vue_data={"msg":result.id}
      resp1=resp(vue_data,200)
      return resp1
    return  resp({"msg":"options method is reading"}, 200)


@app.route('/product_download_csv', methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def product_download_csv():
    if request.method=="POST":
      id=request.json.get("id")
      result=AsyncResult(id)
      vue_data={"msg":result.result}  
      resp1=resp(vue_data,200)
      return resp1
    return resp({"msg":"options method is reading"}, 200)

@cel_app.task
def user_csv():
    fields=["User Name","Product name","Category","Unit","rate_per_unit","Available Quantity"]
    
    csvfile = StringIO()
    csvwriter =csv.writer(csvfile)
    csvwriter.writerow(fields)

    items= UserOrders.query.all()
    for item in items:  
        row = [
             item.user_id,
             item.product_name,
             item.category,
             item.unit,
             item.product_price,
             item.volume_order
             ]
        csvwriter.writerow(row)

    csvfile.seek(0)
    return csvfile.read()


# cahced for 300 seconds
@app.route("/", methods=["GET", "POST"])
def main():
  # page for user login and admin login
  data=products.query.all()
  return render_template("welcome_page.html",data1=data) 


  
@app.route("/ManagerSignup", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def ManagerSignup():
  # user signup page
  if request.method=="POST":
     #with Session(engine, autoflush=False) as sess:
       #sess.begin()
     if(True):
       username=request.json.get("Username")
       email=request.json.get("Email")
       password=request.json.get("Password")
       contact=request.json.get("Mobile")
       
       try:
         U_new_data=PManager(name=username,email=email,password=password,contact=contact,approved=False)
         db.session.add(U_new_data)
         db.session.flush()
         resp1=resp({"msg":"User Credentials Succesffully acdepted"}, 200)
         
       except:
         print("rollback /user_signup")
         db.session.rollback()
         resp1=resp({"msg":"User Credentials already existed"}, 400)
       else:
         db.session.commit()  
         #uid=request.form["user"]
         #return render_template("user_login.html", uid=uid)
       return resp1
  return  resp({"msg":"options method is reading"}, 200)


@app.route("/UserSignUp", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def usersignup():
  # user signup page
  if request.method=="POST":
     #with Session(engine, autoflush=False) as sess:
       #sess.begin()
     if(True):
       username=request.json.get("Username")
       email=request.json.get("Email")
       password=request.json.get("Password")
       contact=request.json.get("Mobile")
       print(username,email,password,contact,"-------------------")
       
       try:
         U_new_data=Users(username=username,email=email,password=password,contact=contact)
         db.session.add(U_new_data)
         db.session.flush()
         resp1=resp({"msg":"User Credentials Succesffully acdepted"}, 200)
         
       except:
         print("rollback /user_signup")
         db.session.rollback()
         resp1=resp({"msg":"User Credentials already existed"}, 400)
       else:
         db.session.commit()  
         #uid=request.form["user"]
         #return render_template("user_login.html", uid=uid)
       return resp1
  return  resp({"msg":"options method is reading"}, 200)

def requires_role(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            token = request.headers.get('Authorization')
            try:
                data = jwt.decode(token, 'your_secret_key', algorithms=['HS256'])
                if data['role'] != role:
                    return jsonify(message='Unauthorized access'), 403
            except:
                return jsonify(message='Invalid token'), 401

            return f(*args, **kwargs)
        return decorated_function
    return decorator




@app.route("/security_protocol",methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def security_protocol():
  if request.method=="POST": 
    v1=request.json.get('data')
    v2=jwt.decode(v1["data"]["msg"].encode('utf-8'), your_secret_key, algorithms=['HS256'])
    print("+++++++++++:",v2["username"])
    if not v1:
      vue_data={"msg":"error with user token id"}
      resp1=resp(vue_data,400)
      return resp1
    vue_data={"msg":v2["username"]}
    resp1=resp(vue_data,200)
    return  resp1
  vue_data={"msg":"v2.username"}
  resp1=resp(vue_data,200)
  return  resp1


@app.route("/UserLogin", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def userlogin():
  # user login page
  if request.method=="POST":   
    uname=request.json.get('username')
    password=request.json.get('password')
    data=Users.query.filter(Users.username==uname).first()
    #
    if not data:
        return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

    if(True):
      if (data.password==password):
        #
        token = jwt.encode({'username': data.username, 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)},
                       your_secret_key, algorithm='HS256')
        vue_data={"msg": token}
        print("--------",token)
        resp1=resp(vue_data,200)
        return resp1
      else:
        resp1=resp({"msg":"password is not maching or not existing"},400)
        return resp1
    else:
      vue_data={"msg":"error with user password"}
      resp1=resp(vue_data,400)
      return resp1
  vue_data={"msg":"Backend-Option method is running in userlogin "}
  resp1=resp(vue_data,200)
  return  resp1

@app.route("/ManagerLogin", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def ManagerLogin():
  # user login page
  if request.method=="POST":   
    uname=request.json.get('username')
    password=request.json.get('password')
    data=PManager.query.filter(PManager.name==uname).first()
    if not data:
        return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

  
    print(data,"your credentials.....")
    if(True):
      if (data.password==password and data.approved):
        token = jwt.encode({ 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)},
                       your_secret_key, algorithm='HS256')
        vue_data={"msg": token}
        print("--------",token)
        resp1=resp(vue_data,200)
        return resp1

      else:
        resp1=resp({"msg":"password is not maching or not existing"},400)
        return resp1
  vue_data={"msg":"Backend-Option method is running in userlogin "}
  resp1=resp(vue_data,200)
  return  resp1
 
@app.route("/AdminLogin", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def AdminLogin():
  # user login page
  #id: adarsh
  #pass: iitm
  if request.method=="POST":   
    uname=request.json.get('username')
    password=request.json.get('password')
    data=Admin.query.filter(Admin.username==uname).first()
    if not data:
        return make_response('Could not verify', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

    print(data,"your credentials.....")
    if(True):
      if (data.password==password):
        token = jwt.encode({ 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)},
                       your_secret_key, algorithm='HS256')
        vue_data={"msg": token}
        print("--------",token)
        resp1=resp(vue_data,200)
        return resp1

        vue_data={"msg":"successful login"}
        resp1=resp(vue_data,200)
        return resp1
      else:
        resp1=resp({"msg":"password is not maching or not existing"},400)
        return resp1
  vue_data={"msg":"Backend-Option method is running in userlogin "}
  resp1=resp(vue_data,200)
  return  resp1


def search_product(products11=products):
  product1=products11.query.all()
  product2=[]
  for i in product1:
    data={"product_name":i.product_name,"category":i.category,"unit":i.unit,"rate":i.rate_per_unit,"quantity":i.quantity}
    product2.append(data)
  return product2



@app.route("/search",methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def search():
  if request.method=="GET":
    query1=request.args.get("search_query")
    try:
      product1=products.query.filter(products.product_name==query1).all()
      if len(product1)==0:
        product1=products.query.filter(products.category==query1).all()
      if len(product1)==0:
        raise
      product2=[]
      for i in product1:
        data={"product_name":i.product_name,"category":i.category,"unit":i.unit,"rate":i.rate_per_unit,"quantity":i.quantity}
        product2.append(data)

      print(product2,"--------------data searched")
      vue_data={"final_data":product2}
      resp1=resp(vue_data,200)
      return resp1
    except:
      # product1=products.query.all()
      # cat=db.session.query(products.category).distinct().all()
      print("Except run")
      product2=[]
      product1=products.query.all()
      for i in product1:
        data={"product_name":i.product_name,"category":i.category,"unit":i.unit,"rate":i.rate_per_unit,"quantity":i.quantity}
        product2.append(data)
      vue_data={"final_data":product2}
      resp1=resp(vue_data,200)
      return resp1
  vue_data={"msg":"search product/category is in process"}
  resp1=resp(vue_data,200)
  return  resp1 



@app.route("/fetch_manager", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def fetch_manager():
  if request.method=="POST":
    product1=PManager.query.filter(PManager.approved==False).all()
    product2=[]
    for i in product1:
      data={"product_name":i.name,"approved":i.approved}
      product2.append(data)
      vue_data={"final_data":product2}
      resp1=resp(vue_data,200)
    vue_data={"final_data":product2}
    resp1=resp(vue_data,200)
    return resp1
  vue_data={"msg":"search product/category is in process"}
  resp1=resp(vue_data,200)
  return  resp1 
  



#fetch_admin_categories
@app.route("/fetch_product", methods=["GET", "POST"])
@cache.cached(timeout=300)
def fetch_product(products=products):
  product1=products.query.all()
  product2=[]
  ii=0
  for i in product1:
    data={"product_name":i.product_name,"category":i.category,"unit":i.unit,"rate":i.rate_per_unit,"quantity":i.quantity}
    product2.append(data)
  vue_data={"final_data":product2}
  resp1=resp(vue_data,200)
  return resp1

@app.route("/fetch_categories", methods=["GET", "POST"])
@cache.cached(timeout=300)
def category():
  category=db.session.query(products.category).distinct().all()
  cat2=[]
  for i in category:
    cat={"category":i[0]}
    cat2.append(cat)
  vue_data={"final_category":cat2}
  resp1=resp(vue_data,200)
  return resp1



@app.route("/mycart",methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def mycart():
  if request.method=="GET":
    username=request.args.get('username')
    print(username,"username at main.py n mycart")
    userdata=UserOrders.query.filter(UserOrders.user_id==username).all()
    userdata2=[]
    if userdata is None:
      data={"product_name":None,"category":None,"unit":None,"rate":None,"quantity":None}
      userdata2.append(data)
    else:
      for i in userdata:
        data={"product_name":i.product_name,"category":i.category,"unit":i.unit,"rate":i.product_price,"quantity":i.volume_order}
        userdata2.append(data)
    vue_data={"final_data":userdata2}
    resp1=resp(vue_data,200)
    return resp1
  else:
    vue_data={"msg":"mycart is running in backend method is not get "}
    resp1=resp(vue_data,200)
    return  resp1 
  
  

@app.route("/Managerapprove",methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def Managerapprove():
  if request.method=="POST":
    name=request.json.get('name')
    response=request.json.get('response')
    print("--------------------",response, name)
    if response=="decline":
      db.session.query(PManager).filter(PManager.name==name).delete()
    else:
      db.session.query(PManager).filter(PManager.name==name).update({"approved":True})
    db.session.flush()
    db.session.commit()
  vue_data={"msg":"mycart is running in backend method is not get "}
  resp1=resp(vue_data,200)
  return  resp1 

               

@app.route("/add_product_by_user", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def add_product_by_user():
  # when user add product, function will update userorder table
  if request.method=="POST":
    user_id=request.json.get("username")
    pname=request.json.get("product_name")
    category=request.json.get("category")
    qnt=int(request.json.get("order_volumne")) 
    pdetail=products.query.filter(products.product_name==pname).first()
    price=pdetail.rate_per_unit
    unit=pdetail.unit
    
    userdata=UserOrders.query.filter(UserOrders.product_name==pname,  
                           UserOrders.user_id==user_id).first()
    old_quantity=pdetail.quantity
    if(qnt>old_quantity):
      qnt=old_quantity
    new_quantity=old_quantity-qnt
    #with Session(engine, autoflush=False) as sess:
       #sess.begin()
    if(True):
       try:
         if(userdata == None): 
           
           new_data=UserOrders(user_id=user_id,category=category,product_name=pname,
               product_price=price,volume_order=qnt,unit=unit,total=qnt*price)
           db.session.add(new_data)
           db.session.flush()
         else:
           db.session.query(UserOrders).filter(UserOrders.product_name==pname,  
                           UserOrders.user_id==user_id).update({"volume_order":qnt})
           db.session.flush()
         db.session.query(products).filter(True,products.product_name==pname).update({"quantity":new_quantity})
         db.session.flush()
       except:
         print("rollback /add product")
         db.session.rollback()
         vue_data={"msg":"user data is not updating at backend"}
         resp1=resp(vue_data,400)
         return  resp1 
       else:
         db.session.commit()
  vue_data={"msg":"user data is Successfully updating at backend"}
  resp1=resp(vue_data,200)
  return  resp1 


@app.route("/delete_mycart", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def delete_mycart():
  #with Session(engine, autoflush=False) as sess:
  if request.method=="POST":
     uid=request.json.get("username")
     pname=request.json.get("product_name")
     print("post in del order is running")
     if(True):
      db.session.query(UserOrders).filter(UserOrders.product_name==pname,
                                    UserOrders.user_id==uid).delete()
      db.session.flush()
      print("post delete order done")
     elif(True):
      print("rollback delete mycart product")
      db.session.rollback()
      vue_data={"msg":"delete product is unsuccessful"}
      resp1=resp(vue_data,400)
      return  resp1 
     db.session.commit()
  vue_data={"msg":"delete product from cart is successfull"}
  resp1=resp(vue_data,200)
  return  resp1 


#delete_admin_product

@app.route("/delete_admin_product", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def delete_admin_product():
  #with Session(engine, autoflush=False) as sess:
  if request.method=="POST":
     pname=request.json.get("product_name")
     print("post in del order is running")
     try:
      db.session.query(products).filter(products.product_name==pname).delete()
      db.session.flush()
      print("post delete order done")
     except:
      print("rollback delete mycart product")
      db.session.rollback()
      vue_data={"msg":"delete product is unsuccessful"}
      resp1=resp(vue_data,400)
      return  resp1 
     db.session.commit()
  vue_data={"msg":"delete product from cart is successfull"}
  resp1=resp(vue_data,200)
  return  resp1 
      

@app.route("/add_product_by_admin", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def add_product_by_admin():
  # when user add product, function will update userorder table
  if request.method=="POST":
    pname=request.json.get("product_name")
    qnt=int(request.json.get("order_volumne")) 
    if(True):
       try:
        db.session.query(products).filter(True,products.product_name==pname).update({"quantity":qnt})
        db.session.flush()
       except:
         print("rollback /add product")
         db.session.rollback()
         vue_data={"msg":"user data is not updating at backend"}
         resp1=resp(vue_data,400)
         return  resp1 
       else:
         db.session.commit()
  vue_data={"msg":"user data is Successfully updating at backend"}
  resp1=resp(vue_data,200)
  return  resp1 


@app.route("/delete_admin_category", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def delete_admin_category():
  #with Session(engine, autoflush=False) as sess:
  if request.method=="POST":
     cname=request.json.get("category")
     print("post in del order is running")
     try:
      db.session.query(products).filter(products.category==cname).delete()
      db.session.flush()
      print("post delete order done")
     except:
      print("rollback delete mycart product")
      db.session.rollback()
      vue_data={"msg":"delete product is unsuccessful"}
      resp1=resp(vue_data,400)
      return  resp1 
     db.session.commit()
  vue_data={"msg":"delete product from cart is successfull"}
  resp1=resp(vue_data,200)
  return  resp1 



#fetch_admin_categories
@app.route("/Only_category_products", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
@cache.cached(timeout=300)
def Only_category_products():
  if request.method=="POST":
    query1=request.json.get("category")
    product1=products.query.filter(products.category==query1).all()
    product2=[]
    ii=0
    for i in product1:
      data={"product_name":i.product_name,"category":i.category,"unit":i.unit,"rate":i.rate_per_unit,"quantity":i.quantity}
      product2.append(data)
    vue_data={"final_data":product2}
    resp1=resp(vue_data,200)
    return resp1
  vue_data={"msg":"delete product from cart is successfull"}
  resp1=resp(vue_data,200)
  return  resp1 


@app.route("/add__new_product_by_admin", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def add__new_product_by_admin():
  # when user add product, function will update userorder table
  if request.method=="POST":
    
    pname=request.json.get("product_name")
    category=request.json.get("category")
    qnt=int(request.json.get("order_volumne")) 
    price=request.json.get("rate")
    unit=request.json.get("unit")

    if(True):
       try:
         my_product=products( category=category,product_name=pname,unit=unit,rate_per_unit=price, quantity=qnt)
         db.session.add(my_product)
         db.session.flush()
       except:
         print("rollback /add product")
         db.session.rollback()
         vue_data={"msg":"user data is not updating at backend"}
         resp1=resp(vue_data,400)
         return  resp1 
       else:
         db.session.commit()
  vue_data={"msg":"user data is Successfully updating at backend"}
  resp1=resp(vue_data,200)
  return  resp1 


@app.route("/total", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def total():
  #with Session(engine, autoflush=False) as sess:
  if request.method=="POST":
     uid=request.json.get("username")
     if(True):
      data=db.session.query(UserOrders).filter(UserOrders.user_id==uid).all()
      db.session.flush()
      count=0
      for i in data:
        count=count+ i.product_price*i.volume_order
     vue_data={"total_Amount":count}
     resp1=resp(vue_data,200)
     return resp1
  

  vue_data={"msg":"delete product from cart is successfull"}
  resp1=resp(vue_data,200)
  return  resp1 
#---------------------------------------------------------

@app.route("/update_user_order", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def user_order():
  if request.method=="POST":
    username=request.json.get('username')
    product_name=request.json.get('product_name')
    order_volumne=request.json.get('order_volumne')
    print("reply from main/user order",username,product_name,order_volumne)
    # data=products.query.filter(products.product_name==pname).first()
    pass
  return  resp({"msg":"Your order is added to your cart successfullly"}, 200)
  


@app.route("/update_mycart", methods=["OPTIONS", "GET", "POST", "PUT", "DELETE"])
def update_mycart():
  uid=request.json.get('username')
  pname=request.json.get('product_name')
  data=UserOrders.query.filter(UserOrders.product_name==pname,  
                           UserOrders.user_id==uid).first()
  pdetail=products.query.filter(products.product_name==pname).first()
  if request.method=="POST":
    vol=request.json.get('order_volumne')
    #with Session(engine, autoflush=False) as sess:
     #sess.begin()
    if(True):
     try:
      db.session.query(UserOrders).filter(UserOrders.product_name==pname,  
                           UserOrders.user_id==uid).update({"volume_order":vol})
      db.session.flush()
     except:
      print("rollback /add product")
      db.session.rollback()
      return  resp({"msg":"Error in updating data"}, 400)
     else:
      db.session.commit()
      return  resp({"msg":"Your order is added to your cart successfullly"}, 200)
  return   resp({"msg":"Your order is added to your cart successfullly"}, 200)

def up1(qnt,pname):
   with Session(engine, autoflush=False) as sess:
       sess.begin()
       sess.query(products).filter(products.product_name==pname).update({})
       sess.flush()
       sess.commit()
   return None
  

  
@app.route("/admin_search",methods=["POST"])
def admin_search():
  query1=request.form["query"]
  aid=request.args["aid"]
  try:
    product1=products.query.filter(products.product_name==query1).all()
    if len(product1)==0:
      product1=products.query.filter(products.category==query1).all()
    if len(product1)==0:
      raise
    return render_template("admin_product_database.html",products=product1,aid=aid)   
  except:
    product1=products.query.all()
    return render_template("admin_product_database.html",products=product1,aid=aid)   
  
  
@app.route("/add_product", methods=["GET", "POST"])
def add_product():
  #add product by database category wise
  aid=request.args["aid"]
  if request.method=="POST":
    pname=request.form["pname"]; psec=request.form["psec"]
    unit=request.form["unit"]
    rate=request.form["rate"]
    stock=request.form["stock"]
    #with Session(engine, autoflush=False) as sess:
     #sess.begin()
    if(True):
     try:
      my_product=products( category=psec,product_name=pname,unit=unit,
                          rate_per_unit=rate, quantity=stock)
      db.session.add(my_product)
      db.session.flush()
     except:
      print("rollback /add product")
      db.session.rollback()
      return render_template("Error_page.html")
     else:
      db.session.commit()
      product1=products.query.all()
      return render_template("admin_product_database.html",products=product1,aid=aid)   
  return render_template("Error_page.html")
  
@app.route("/category_managemnt", methods=["GET", "POST"])
def category_managemnt():
  #add product by database category wise
  aid=request.args["aid"]
  print("cat meth ", request.method)
  if request.method=="POST":
    return render_template("admin_add_product.html",aid=request.args["aid"]) 
  product1=db.session.query(products.category).distinct().all()  
  return render_template("category.html",products=product1,aid=request.args["aid"])

@app.route("/category_filter", methods=["GET", "POST"])
def category_filter():
  #add product by database category wise
  aid=request.args["aid"]
  cat=request.args["cat"]
  data=products.query.filter(products.category==cat).all()  
  return render_template("admin_product_database.html",products=data,aid=aid)   
  

@app.route("/remove_category", methods=["GET", "POST"])
def remove_category():
  #with Session(engine, autoflush=False) as sess:
  if(True):
     aid=request.args["aid"]
     cat=request.args["cat"]
     #sess.begin()
     try:
      db.session.query(products).filter(products.category==cat).delete()
      db.session.flush()
     except:
      print(" delete category")
      db.session.rollback()
      return render_template("Error_page.html")
     else:
      db.session.commit()
  product1=db.session.query(products.category).distinct().all()  
  return render_template("category.html",products=product1,aid=request.args["aid"])
    
  
@app.route("/delete_product", methods=["GET", "POST"])
def delete_product():
  #with Session(engine, autoflush=False) as sess:
  if(True):
     aid=request.args["aid"]
     pname=request.args["pname"]
     #sess.begin()
     try:
      db.session.query(products).filter(products.product_name==pname).delete()
      db.session.flush()
     except:
      print(" delete rollback /add product")
      db.session.rollback()
      return render_template("Error_page.html")
     else:
      db.session.commit()
  product1=products.query.all()
  return render_template("admin_product_database.html",products=product1,aid=aid)
      
        
@app.route("/update_product", methods=["GET", "POST"])
def update_product():
  aid=request.args["aid"]
  pname=request.args["pname"]
  data=products.query.filter(products.product_name==pname).first()
  if request.method=="POST":
    #with Session(engine, autoflush=False) as sess:
     #sess.begin()
    if(True):
     try:
      db.session.query(products).filter(products.product_name==pname).update({
                         "product_name":request.form["pname"],
                         "category":request.form["psec"],
                         "unit":request.form["unit"],
                         "rate_per_unit":request.form["rate"],
                         "quantity":request.form["quantity"]})
      db.session.flush()
     except:
      print("update rollback /add product")
      db.session.rollback()
      return render_template("Error_page.html")
     else:
      db.session.commit()
      #sess.refresh()
    product1=products.query.all()
    return render_template("admin_product_database.html",products=product1,aid=aid)  
  return render_template("update_product.html",products=data, aid=aid) 


if __name__ == '__main__':
    app.run(debug=True, port=5000)
