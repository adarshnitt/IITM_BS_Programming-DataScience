
Application:  
     It contains applications files :
Config.py:
     Configuration File
Controller.py: 
     It has all App Controllers code.
DataBase.py: 
     It support  code or DataBase Management using SQLAlchemy
Models.py: 
     It contains all models which help to run current application.
Static: 
     It Contains all default Static files i.e. images etc
DB: 
     It contains sqlite DB
templates:
     Default flask template folder
App.py: 
     Python file to run our application
Requirement.txt:
     It contains all required libraries and other dependencies for our application.




                        Steps to run our application:
1- Create a virtual environment i.e. venv
2- $ python -m venv // activate virtual environment
3- $ python3 app.py // Run Flask application as local development at  http://127.0.0.1:8080
4- npm run serve



