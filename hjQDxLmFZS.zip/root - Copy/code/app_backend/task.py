from celery import shared_task
import smtplib
from celery.schedules import crontab
import pdfkit
import time


from worker import cel_app


import datetime
from io import StringIO
import csv
from jinja2 import Template
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
import pdfkit
from email import encoders
import myreminder

from application.models import products, Users,Admin, UserOrders
from application.database import db
from flask_caching import Cache

from flask import Response

@cel_app.task
def send_mail():
    myreminder.send_mail("adarsh@gmail.com","Greet message","Reimnder from adarsh grocery store. we are missing you, have a visit soon.")


@cel_app.task
def send_mail_report():
    myreminder.monthly_reminder()


@cel_app.on_after_configure.connect
def setup_periodic_task(sender, **kwargs):
  sender.add_periodic_task(10,msg.s(), name="-----------Good morning adarsh")
  sender.add_periodic_task(30,send_mail.s(), name="----------Happy shopping")
  sender.add_periodic_task(60,send_mail_report.s(), name="----------Report mail sending by task.py action")
  
  # 1 day of month reminder
  sender.add_periodic_task(crontab(hour=8,min=30,day_of_month=1), msg.s(),name="greet at first day of month")
  sender.add_periodic_task(crontab(hour=8,min=30,day_of_month=1), send_mail.s(),name="greet at first day of month")
  



@cel_app.task
def product_csv():
    fields=["Product Name","Category","Unit","rate_per_unit","Available Quantity"]
    
    csvfile = StringIO()
    csvwriter =csv.writer(csvfile)
    csvwriter.writerow(fields)

    items= products.query.all()
    for item in items:  
        row = [
             item.product_name,
             item.category,
             item.unit,
             item.rate_per_unit,
             item.quantity]
        csvwriter.writerow(row)

    csvfile.seek(0)
    return csvfile.read()

@cel_app.task
def user_csv():
    fields=["User Name","Product name","Category","Unit","rate_per_unit","Available Quantity"]
    
    csvfile = StringIO()
    csvwriter =csv.writer(csvfile)
    csvwriter.writerow(fields)

    items= UserOrders.query.all()
    for item in items:  
        row = [
             item.user_id,
             item.product_name,
             item.category,
             item.unit,
             item.product_price,
             item.volume_order
             ]
        csvwriter.writerow(row)

    csvfile.seek(0)
    return csvfile.read()


@cel_app.task
def msg():
    return "Goodmorning Adarsh"



