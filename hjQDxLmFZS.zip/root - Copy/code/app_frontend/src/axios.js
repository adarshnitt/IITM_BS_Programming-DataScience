import axios from 'axios';
//axios.post is a method provided by the Axios library for making HTTP POST requests to a server or API.
// It sends an HTTP POST request to the specified URL

axios.defaults.withCredentials = true;

const baseURL = 'http://localhost:5000';

const instance = axios.create({
  baseURL: baseURL,
});

export default instance;