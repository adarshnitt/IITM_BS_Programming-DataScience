// router.js

import { createRouter, createWebHistory } from 'vue-router';
import UserLogin from './components/UserLogin.vue'; // Replace with your actual component path
import WelcomePage from './components/WelcomePage.vue'; // Replace with your actual component path
import AdminLogin from './components/AdminLogin.vue'; // Replace with your actual component path
import ErrorPage from './components/ErrorPage.vue'; // Replace with your actual component path
import ProductPage from './components/ProductPage.vue'; // Replace with your actual component path
import UserSignUp from './components/UserSignUp.vue'; // Replace with your actual component path
import MyCart from './components/MyCart.vue'; // Replace with your actual component path
import Update_order from './components/Update_order.vue'
import AdminProductDatabase from './components/AdminProductDatabase.vue'
import Update_admin_product from './components/Update_admin_product.vue'
import delete_category from './components/delete_category.vue'
import Category_Analysis from './components/Category_Analysis.vue'
import Only_category_products from './components/Only_category_products.vue'
import add_category from './components/add_category.vue'
import PManager from './components/PManager.vue'
import PManagerSignUP from './components/PManagerSignUP.vue'
import PManagerLogin from './components/PManagerLogin.vue'
import ApproveManager from './components/ApproveManager.vue'



const routes = [
    { path: '/', component: WelcomePage },
  { path: '/UserLogin', name:'UserLogin',component: UserLogin },
  { path: '/AdminLogin', name:'AdminLogin', component: AdminLogin },
  { path: '/ProductPage', name:'ProductPage', component: ProductPage },
  { path: '/ErrorPage', name:'ErrorPage',component: ErrorPage },
  { path: '/UserSignUp',name:'UserSignUp', component: UserSignUp },
  { path: '/MyCart',name:'MyCart', component: MyCart },
  { path: '/ErrorPage',name:'ErrorPage', component: ErrorPage },
  { path: '/Update_order',name:'Update_order', component: Update_order },
  { path: '/AdminProductDatabase',name:'AdminProductDatabase', component: AdminProductDatabase },
  { path: '/Update_admin_product',name:'Update_admin_product', component: Update_admin_product },
  { path: '/delete_category',name:'delete_category', component: delete_category },
  { path: '/Category_Analysis',name:'Category_Analysis', component: Category_Analysis },
  { path: '/Only_category_products',name:'Only_category_products', component: Only_category_products },
  { path: '/add_category',name:'add_category', component: add_category },
  { path: '/PManager',name:'PManager', component: PManager },
  { path: '/PManagerSignUP',name:'PManagerSignUP', component: PManagerSignUP },
  { path: '/PManagerLogin',name:'PManagerLogin', component: PManagerLogin },
  { path: '/ApproveManager',name:'ApproveManager', component: ApproveManager }
  
  // Add more routes as needed  
];



const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;