<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:rgb(57, 208, 100);padding-bottom:200px;height:100%;border:3px solid black">
 
 <div class="container" style="text-align:center;border-style:outset;background-color:pink;padding-bottom:200px;height:100%;border:3px solid black">
 
  <div class="container" style="width: 80%; float:center; padding-top:15px;text-align:center "> 
  <h1><p class="text-capitalize" > Update user order :{{ product_name }} </p></h1>
  </div>
  
  <router-link to="/" style="padding-right:15px;" class="btn btn-primary" role="button"> Home </router-link>
  <router-link :to="{name:'AdminProductDatabase', params:{'username':username}}"  class="btn btn-primary" role="button"> Admin </router-link>
  
  
  <div class="container" style="border-style:inset;" >  
    <form @submit.prevent="delete1">
        <label for="selectOption">Select a Category:</label>
        <select id="selectOption" v-model="dcategory">
            <option v-for="category in cat.final_category" :key="category.category" :value="category.category">
               {{ category.category }} <br>
        </option>
        </select> <br> <br>
    
          <button type="submit">Delete</button>
    </form>
  </div>
  </div>
  
 </div>
</template>

<script>
import axios from "@/axios"
// @ means src dir
export default {
    name:'delete_category',
    data(){
      return {
        username:"",
        dcategory:"",
        product_name:"",
        rate:"",
        unit:"",
        quantity:"",
        cat:[]
      }
    },
    mounted(){
        this.fetchdata();
    this.username = this.$route.params.username;
    },
    methods: {
        async fetchdata(){
           const resp1=await axios.get('http://localhost:5000/fetch_categories')
           this.cat=resp1.data
        },
        async delete1(){
            console.log(this.dcategory+" : category select hui hai")
            try{
             const data={
                        "category":this.dcategory
                        };
                   await axios.post("/delete_admin_category",data)
                   alert("Your Category: "+this.dcategory+" : Updated successfully, Refresh it")
                   this.$router.push({
                   name:'AdminProductDatabase',
                        params:{
                            "username":this.username
                                    }
                         }
                    );
      } catch(error)
      {
        console.error("Error",error)
        this.$router.push("/");
      }
    }
  }
}
</script>