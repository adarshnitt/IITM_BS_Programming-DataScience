<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:rgb(72, 196, 95);padding-bottom:200px;height:100%;border:3px solid black">
 
      <div class="container" style="border:solid;border-style:outset;text-align:center">
        <div style="width:100%">
          <form @submit.prevent="search(username)">
            <input
               class="text"
               v-model="search_query"
               type="text"
               id="search_query"
               name="search_query"
               placeholder="search_query"
               required
             /> 
             <br>
           <button   type="submit">Search</button>
           </form>
            Welcome User: {{ username }} 
            <router-link to="/" > Logout </router-link> <br>
      </div>
        <h1> Category Analysis</h1>
        <router-link :to="{name:'AdminProductDatabase', params:{'username':username }}"  class="btn btn-primary" role="button"> Products </router-link>
        <router-link :to="{name:'AdminLogin', params:{'username':username }}"  class="btn btn-primary" role="button"> Home </router-link>
        
        <br>
        </div>
        <div>
        <div>
          <div>
            <table>
              <thead>
              <tr>
                <th>Category Name</th>
                <th>Update</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(row, index) in cat['final_category']" :key="index">
                <td>{{ row.category }}</td>
                <td v-if="username == 'adarsh'"><router-link :to="{name:'delete_category', params:{'username':username,'category':row.category,'product_name':row.product_name,'rate':row.rate,'unit':row.unit,'quantity':row.quantity }}"  class="btn btn-primary" role="button"> Delete </router-link>
                </td>   
                <td><router-link :to="{name:'Only_category_products', params:{'username':username,'category':row.category,'product_name':row.product_name,'rate':row.rate,'unit':row.unit,'quantity':row.quantity }}"  class="btn btn-primary" role="button"> Update </router-link>
                </td> 
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <p v-if="username == 'adarsh'">
      <router-link :to="{name:'add_category', params:{'username':username}}"  class="btn btn-primary" role="button"> Add category </router-link>
      </p>
      <br>
      <button  @click="User_Report" class="btn btn-primary" role="button"> User Report </button>
      <button  @click="Product_Report" class="btn btn-primary" role="button"> Product Report </button>
      
      </div>
      </template>
    
    
    
    <script>
    import axios from "@/axios";
    export default {
        name:'Category_Analysis',
        data(){
          return { 
        product:[],
        cat:[],
        val1:"",
        order_volumne:0,
        product_name:"",
        username:'',
        search_query:"",
        id:""
      }
          
        },
        mounted()
        {
          this.fetchdata();
          this.username= this.$route.params.username;
        },
        methods: {
          save(filename, data) {
                const csvContent = data.replace('\r\n',"\n")
                const blob = new Blob([csvContent], {type: 'text/csv;charset=utf-8;'});
                if(window.navigator.msSaveOrOpenBlob) {
                    window.navigator.msSaveBlob(blob, filename);
                                                      }
                 else{
                         const elem = window.document.createElement('a');
                         elem.href = window.URL.createObjectURL(blob);
                         elem.download = filename;        
                        document.body.appendChild(elem);
                        elem.click();        
                        document.body.removeChild(elem);
                      }
            },
            async fetchdata(){
                 const resp1=await axios.get('http://localhost:5000/fetch_categories')
                 this.cat=resp1.data
                 },
            async update(product)
                 {
                  this.del_cat=product
                  const data={
                    "cat_name":product,
                    "username":this.username,
                    };
                 const del1=await axios.post("/delete_admin_product",data);
                 console.log(del1)
                 alert(this.del_product_name+" :Order deleted successfully, Refresh it")
                 },
                 async search(username)
          {
             const data={
              "username":username,
              "search_query":this.search_query
             };
             const prod111=await axios.get("/search",{params:data});
             this.product=prod111.data
             console.log(this.product+"------------------------------------searh get done")
          },
          async submit(){
            try{
                 const data={
                            username:this.username,
                            password:this.password
                            };
            const output=await axios.post("/AdminLogin",data)
            console.log("response data",output),
            //  go to /product an use mount to access params
            this.$router.push({
              name:'Category_Analysis',
              params:{
                "username":this.username
                     }
                }
              );
          } catch(error)
          {
            console.error("Error",error)
            this.$router.push("/UserSignUp");
          }
        },
        async Product_Report(){
            const id=await axios.post("/product_export_csv")
            this.id=id.data.msg
            alert("product report is in process with id :"+this.id)
            console.log(this.id)

            const data={
                        id:this.id,
                        };
            const res=await axios.post("/product_download_csv",data)
            const res1=JSON.stringify(res.data.msg)
            let rows = res1.split("\n");
            let csvData = rows.map(row => row.split(","));
            let csvString = csvData.map(row => row.join(",")).join("\n");

            console.log(csvString);
            this.save(new Date()+"_products_"+".csv", csvString)

            this.$router.push({
              name:'Category_Analysis',
              params:{
                "username":this.username
                     }
                }
              );

        },
        async User_Report(){
            const id=await axios.post("/user_export_csv")
            this.id=id.data.msg
            alert("product report is in process with id :"+this.id)
            console.log(this.id)

            const data={
                        id:this.id,
                        };
            const res=await axios.post("/user_download_csv",data)
            const res1=JSON.stringify(res.data.msg)
            let rows = res1.split("\n");
            let csvData = rows.map(row => row.split(","));
            let csvString = csvData.map(row => row.join(",")).join("\n");

            console.log(csvString);
            this.save(new Date()+"_users_"+".csv", csvString)

            this.$router.push({
              name:'Category_Analysis',
              params:{
                "username":this.username
                     }
                }
              );

        },
      }
      }
    </script>

    
    


