<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:pink;padding-bottom:200px;height:100%;border:3px solid black">
 
        <router-link to="/" style="padding-right:15px;" class="btn btn-primary" role="button"> Home </router-link>
        <router-link :to="{name:'ProductPage', params:{'username':username}}"  class="btn btn-primary" role="button"> Website </router-link>
      <div>
        <h1>My Cart <br><br> {{ username }} </h1><br><br> 
        <div v-if="userorder">
          <div>
            <table>
              <thead>
              <tr>
                <th>Category</th>
                <th>Product</th>
                <th>Price</th>
                <th>Unit</th>
                <th>Qunatity</th>
                <th>Update</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(row, index) in userorder['final_data']" :key="index">
                <td>{{ row.category }}</td>
                <td>{{ row.product_name }}</td>
                <td>{{ row.rate }}</td>
                <td>{{ row.unit }}</td>
                <td>{{ row.quantity }}</td>
                <td><router-link :to="{name:'Update_order', params:{'username':username,'category':'row.category','product_name':row.product_name,'rate':row.rate,'unit':row.unit,'quantity':row.quantity }}"  class="btn btn-primary" role="button"> Update </router-link>
      </td>   
              <td> <button @click="delete_data(row.product_name)">Delete</button></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div v-else>
          <h1> You have not shopped yet!</h1>

        </div>

        
      </div>
      Total Amount of purchase is: {{ total["total_Amount"] }} Rupee.
    </div>
</template>

<script>
import axios from "@/axios"
export default {
    name: "MyCart",
    data(){
      return {
        userorder:[],
        username:'',
        del_product_name:"",
        total:0
      }
    },
    mounted(){
      this.username=this.$route.params.username;
      this.fetchdata();
    },
    methods:
    {
      async fetchdata(){
        const resp=await axios.get(`http://localhost:5000/mycart?username=${this.username}`)
        console.log(" get from mycart  in .vue")
        this.userorder=resp.data

        const data1={
                    "username":this.username,
                    };
        const tot=await axios.post("/total",data1)
        console.log(" get from mycart  in .vue")
        this.total=tot.data



      },
      async delete_data(product)
      {
        this.del_product_name=product
        const data={
                    "product_name":product,
                    "username":this.username,
                    };
        const del1=await axios.post("/delete_mycart",data);
        console.log(del1)
        alert(this.del_product_name+" :Order deleted successfully, Refresh it")
      }
    }
}
</script>

