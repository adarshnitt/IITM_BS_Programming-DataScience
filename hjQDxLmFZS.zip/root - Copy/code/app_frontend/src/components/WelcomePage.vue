<template>
  <div class="container" style="text-align:center;border-style:outset;background-color:rgb(95, 94, 166);padding-bottom:200px;height:100%;border:3px solid black">
 
    <div class="container" style="text-align:center;border-style:outset;background-color:#E6E6FA;padding-bottom:200px;height:100%">
    <h1> Shopping App</h1><br><br>
 id: adarsh
 pass: iitm<br>
    <div style="padding-top:50px;">
    <div style="color:red">
    <h4> "Shopping is Delightful dance between Desire and Discovery ..." </h4> <br><br>
    </div>
      <h1 class="display-4"> Welome</h1> 
    </div>
    <div>
    <router-link to="/UserLogin" class="btn btn-primary" role="button">User login</router-link>
    <router-link to="/AdminLogin"  class="btn btn-primary" role="button">Admin login</router-link>
    <router-link to="/PManagerLogin"  class="btn btn-primary" role="button">Product Manager</router-link>
    </div>
 </div>
  </div>
</template>
export default {
    name:WelcomePage
}
    
