<template>
  <div class="container" style="text-align:center;border-style:outset;background-color:rgb(91, 203, 86);padding-bottom:200px;height:100%;border:3px solid black">
 
<div class="container" style="text-align:center;border-style:outset;background-color:rgb(108, 194, 99);padding-bottom:200px;height:100%;border:3px solid black">

<div class="container" style="width: 80%; float:center; padding-top:15px;text-align:center "> 
<h1><p class="text-capitalize" > Admin Login </p></h1>
</div>
<router-link to="/" style="" class="btn btn-primary"  role="button"> Home </router-link>


<div class="container" style="border-style:inset;" >  
  <form @submit.prevent="submit">
    <label for="username">Username:</label>
        <input
          class="text"
          v-model="username"
          type="text"
          id="username"
          name="username"
          placeholder="Username"
          required
        /> <br>
        <label for="password">PassWord:</label>
        <input
          class="text"
          v-model="password"
          type="text"
          id="password"
          name="password"
          placeholder="password"
          required
        /><br>
        <button type="submit">Admin Login</button>
      </form>
</div>
</div>
</div>
</template>

<script>
import axios from "@/axios"
// @ means src dir
export default {
  name:'AdminLogin',
  data(){
    return {
      username:"",
      password:""
    }
    
  },
  methods: {
    async submit(){
      try{
           const data={
                      username:this.username,
                      password:this.password
                      };
      const output=await axios.post("/AdminLogin",data)

      
      const out0={"data":output}
      const output1= await axios.post("/security_protocol", out0)
      console.log("response data",output,output1)
      alert("JWT successfull  Admin login:" +output1["data"].msg)
      //  go to /product an use mount to access params
      this.$router.push({
        name:'AdminProductDatabase',
        params:{
          "username":this.username
               }
          }
        );
    } catch(error)
    {
      console.error("Error",error)
      this.$router.push("/UserSignUp");
    }
  }
}
}

</script>