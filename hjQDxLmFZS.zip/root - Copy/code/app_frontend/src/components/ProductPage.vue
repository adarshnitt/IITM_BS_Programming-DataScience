<template>
  <div class="container" style="text-align:center;border-style:outset;background-color:pink;padding-bottom:200px;height:100%;border:3px solid black">
 
   <div class="container" style="border: 1px solid black;text-align:center; height:100%; width:90%">
    <div class="row" style="height:80px;">
      <div class="header" style=" width:70%; float:left;text-align:center;background-color:#FFFFCC">
           <h5> Adarsh's  Shopping Website </h5>
      </div>
      <div class="header topnav" style="background-color:#FFFFCC; width:30%; float:left;text-align:center;">
        <div style="width:100%">
            <form @submit.prevent="search(username)">
              <input
                 class="text"
                 v-model="search_query"
                 type="text"
                 id="search_query"
                 name="search_query"
                 placeholder="search_query"
                 required
               /> 
               <br>
             <button   type="submit">Search</button>
             </form>
              Welcome User: {{ username }} 
              
            <router-link to="/" > Logout </router-link> <br>
            <router-link :to="{name:'MyCart', params:{'username':username}}" > Mycart </router-link>
        </div>
      </div>
    </div>
   </div>
      <br>
    <div>
      <div class="container" style="background-color:#FFFFE0" >
       
      <div v-for="category in cat['final_category']" :key="category.category">
        <div style="color:red" :id="category.category">
          <h1> {{category["category"]}}</h1>
          <div v-for="item in product['final_data']" :key="item.product_name">
              <div v-if="category['category']==item.category">
                <div style="border: 1px solid black; color: Green">
                 <h3>{{ item["product_name"] }} </h3>
                <div>
                  Rate:{{ item["rate"] }} Rupee  / {{ item["unit"] }} <br>
                  Avialable Qunatity: {{ item["quantity"] }}<br>
  <div v-if='item.quantity >0' >  
    <form @submit.prevent="add_product_by_user(item['product_name'], item['category'])">
      <label for="order_volume">Your Order Volume:</label>
          <input
            class="text"
            v-model="order_volumne"
            type="text"
            id="order_volume"
            name="order_volume"
            placeholder="Quantity"
            required
          /> 
          <br>
          <button   type="submit">Order</button>
        </form>
  </div>
                </div>
                </div>
              </div>
          </div>
        </div>
      </div>
        -----------------------
      </div>
    </div>
  </div>
</template>


<script>
import axios from "@/axios"
export default {
    name:"ProductPage",
    data(){
      return { 
        product:[],
        cat:[],
        val1:"",
        order_volumne:0,
        product_name:"",
        username:'',
        search_query:""
      }
    },
    mounted(){
      this.fetchdata();
      this.username=this.$route.params.username;
      console.log(this.username);
      console.log("----- mounted in product; above printed username who logged");
      console.log(this.$route.params.username)

    },
    methods:
    {
      async fetchdata(){
        const resp=await axios.get('http://localhost:5000/fetch_product')
        this.product=resp.data

        const resp1=await axios.get('http://localhost:5000/fetch_categories')
        this.cat=resp1.data
      },
      async search(username)
      {
         const data={
          "username":username,
          "search_query":this.search_query
         };
         const prod111=await axios.get("/search",{params:data});
         this.product=prod111.data
         console.log(this.product+"------------------------------------searh get done")
      },
      async add_product_by_user(product_name, category){
        try{
             const data={
                        "order_volumne":this.order_volumne,
                        "product_name":product_name,
                        "username":this.username,
                        "category":category
                        };
        await axios.post("/add_product_by_user",data)
        this.order_volumne=0
        this.$router.push({
          name:'ProductPage',
          params:{
            "username":this.username
                 }
            }
          );
      } catch(error)
      {
        console.error("Error",error)
        this.$router.push("/UserSignUp");
      }
    }
    }
}
</script>
