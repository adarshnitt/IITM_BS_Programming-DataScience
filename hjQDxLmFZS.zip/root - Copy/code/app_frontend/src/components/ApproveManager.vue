<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:rgb(81, 207, 148);padding-bottom:200px;height:100%;border:3px solid black">
 
        <div class="container" style="width: 80%; float:left; padding-top:15px;text-align:center "> 
  
    <h1>List of Approvals</h1>
    
  </div> 
  <br>
  <div class="container" style="padding-top:15px">
    <router-link :to="{name:'AdminProductDatabase', params:{'username':username }}"  class="btn btn-primary" role="button"> Products </router-link>
        <router-link :to="{name:'AdminLogin', params:{'username':username }}"  class="btn btn-primary" role="button"> Home </router-link>
        
  </div>
  <div>
    
        <div v-if='manager["final_data"]'>
          <div>
            <table>
              <thead>
              <tr>
                <th>Product Manager Name</th>
                <th>Action</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(row, index) in manager['final_data']" :key="index">
                <td>{{ row.product_name}}</td>
              <td>
                 <button @click="delete_data(row.product_name,'accept')">Accept</button>  
                 <button @click="delete_data(row.product_name,'decline')">Decline</button>
             </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div v-else>
          <h1> You have not shopped yet!</h1>

        </div>

        
      </div>

  </div>
</template>


<script>

import axios from "@/axios"
export default {
    name: "ApproveManager",
    data(){
      return {
      Username:"",
      approved:"",
      manager:[]
    }
  },
  mounted()
        {
          this.fetchdata();
          this.username= this.$route.params.username;
        },
  methods: {
    async fetchdata(){
             const resp=await axios.post('http://localhost:5000/fetch_manager')
             this.manager=resp.data
      },

      async  delete_data(name, response)
      {
             const data={
                        name:name,
                        response:response
                        };

        await axios.post("http://localhost:5000/Managerapprove",data)
        alert(" Refresh it")
      },
     async Signup(){
        try{
             const data={
                        Username:this.Username,
                        approved:this.approved
                        };
        const output=await axios.post("/ManagerSignup",data)
        console.log("response data",output)
        alert(" Manger Approved  successfully")
        this.$router.push("/UserLogin");
      } catch(error)
      {
        console.error("Error",error)
        this.$router.push("/ErrorPage");
      }
    }
  },
}
</script>

