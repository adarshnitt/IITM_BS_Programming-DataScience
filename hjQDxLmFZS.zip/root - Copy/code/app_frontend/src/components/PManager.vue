<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:rgb(208, 226, 96);padding-bottom:200px;height:100%;border:3px solid black">
 
      <div class="container" style="border:solid;border-style:outset;text-align:center">
        <div style="width:100%">
          <form @submit.prevent="search(username)">
            <input
               class="text"
               v-model="search_query"
               type="text"
               id="search_query"
               name="search_query"
               placeholder="search_query"
               required
             /> 
             <br>
           <button   type="submit">Search</button>
           </form>
            Welcome User: {{ username }} 
            <router-link to="/" > Logout </router-link> <br>
      </div>
        <h1> Product Manager Database:- Product Registration/Deregistration</h1>
        <router-link :to="{name:'Category_Analysis', params:{'username':username }}"  class="btn btn-primary" role="button"> Category_Analysis </router-link>
        
        <br>
        </div>
        <div>
        
        <div>
          <div>
            <table>
              <thead>
              <tr>
                <th>Category</th>
                <th>Product</th>
                <th>Price</th>
                <th>Unit</th>
                <th>Qunatity</th>
                <th>Update</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(row, index) in product['final_data']" :key="index">
                <td>{{ row.category }}</td>
                <td>{{ row.product_name }}</td>
                <td>{{ row.rate }}</td>
                <td>{{ row.unit }}</td>
                <td>{{ row.quantity }}</td>
                <td><router-link :to="{name:'Update_admin_product', params:{'username':username,'category':'row.category','product_name':row.product_name,'rate':row.rate,'unit':row.unit,'quantity':row.quantity }}"  class="btn btn-primary" role="button"> Update </router-link>
      </td>   
              <td> <button @click="delete_data(row.product_name)">Delete</button></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      </div>
      </template>
    
    
    
    <script>
    import axios from "@/axios";

    export default {
        name:'PManager',
        data(){
          return { 
        product:[],
        cat:[],
        val1:"",
        order_volumne:0,
        product_name:"",
        username:'',
        search_query:""
      }
          
        },
        mounted()
        {
          this.fetchdata();
          this.username= this.$route.params.username;
        },
        methods: {
          async fetchdata(){
             const resp=await axios.get('http://localhost:5000/fetch_product')
             this.product=resp.data

            const resp1=await axios.get('http://localhost:5000/fetch_categories')
            this.cat=resp1.data
      },
      async delete_data(product)
      {
        this.del_product_name=product
        const data={
                    "product_name":product,
                    "username":this.username,
                    };
        const del1=await axios.post("/delete_admin_product",data);
        console.log(del1)
        alert(this.del_product_name+" :Order deleted successfully, Refresh it")
      },
          async search(username)
          {
             const data={
              "username":username,
              "search_query":this.search_query
             };
             const prod111=await axios.get("/search",{params:data});
             this.product=prod111.data
             console.log(this.product+"------------------------------------searh get done")
          },
          async submit(){
            try{
                 const data={
                            username:this.username,
                            password:this.password
                            };
            const output=await axios.post("/AdminLogin",data)
            console.log("response data",output),
            //  go to /product an use mount to access params
            this.$router.push({
              name:'AdminProductDatabase',
              params:{
                "username":this.username
                     }
                }
              );
          } catch(error)
          {
            console.error("Error",error)
            this.$router.push("/UserSignUp");
          }
        }
      }
      }
      

      
    </script>

    
    