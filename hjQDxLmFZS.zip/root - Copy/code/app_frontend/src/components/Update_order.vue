<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:pink;padding-bottom:200px;height:100%;border:3px solid black">
 
 <div class="container" style="text-align:center;border-style:outset;background-color:pink;padding-bottom:200px;height:100%;border:3px solid black">
 
  <div class="container" style="width: 80%; float:center; padding-top:15px;text-align:center "> 
  <h1><p class="text-capitalize" > Update user order :{{ product_name }} </p></h1>
  </div>
  <router-link to="/" style="padding-right:15px;" class="btn btn-primary" role="button"> Home </router-link>
  <router-link :to="{name:'ProductPage', params:{'username':username}}"  class="btn btn-primary" role="button"> Website </router-link>
  <router-link :to="{name:'MyCart', params:{'username':username}}"  class="btn btn-primary" role="button"> MyCart </router-link>
     
  
  <div class="container" style="border-style:inset;" >  
    <form @submit.prevent="update">
          username:{{ username }}<br>
          category:{{ category }}<br>
          product_name:{{ product_name }}<br>
          rate:{{ rate }}<br>
          unit:{{ unit }}<br>
          <label for="Quntity">New Order Quntity:</label>
          <input
            class="text"
            v-model="quantity"
            type="text"
            id="Quntity"
            name="Quntity"
            placeholder="Quntity"
            required
          /><br>
          <button type="submit">Update</button>
        </form>
  </div>
  </div>
 </div>
</template>

<script>
import axios from "@/axios"
// @ means src dir
export default {
    name:'Update_order',
    data(){
      return {
        username:"",
        category:"",
        product_name:"",
        rate:"",
        unit:"",
        quantity:""
      }
    },
    mounted(){
    this.username = this.$route.params.username;
    this.category = this.$route.params.category;
    this.product_name = this.$route.params.product_name;
    this.rate = this.$route.params.rate;
    this.unit = this.$route.params.unit;
    this.quantity = this.$route.params.quantity;
    },
    methods: {
      async update(){
        try{
             const data={
                        "username":this.username,
                        "order_volumne":this.quantity,
                        "category":this.category,
                        "product_name":this.product_name
                        };
        await axios.post("/add_product_by_user",data)
        //  go to /product an use mount to access params
        this.$router.push({
          name:'MyCart',
          params:{
            "username":this.username
                 }
            }
          );
      } catch(error)
      {
        console.error("Error",error)
        this.$router.push("/UserSignUp");
      }
    }
  }
}
</script>