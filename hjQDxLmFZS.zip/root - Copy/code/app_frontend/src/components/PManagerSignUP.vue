<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:rgb(201, 230, 88);padding-bottom:200px;height:100%;border:3px solid black">
 
        <div class="container" style="width: 80%; float:left; padding-top:15px;text-align:center "> 
  <p class="text-capitalize" >
    <b>Product Manager Signup</b>
    </p>
  </div>
  <div class="container" style="padding-top:15px">
    <router-link to="/"   class="btn btn-primary" role="button">Home </router-link>
  </div>
  
  <div class="container" style="padding-top: 25px">  
    <form @submit.prevent="Signup">
          <label for="username">Product Manger name:</label>
          <input
            class="text"
            v-model="Username"
            type="text"
            id="username"
            name="username"
            placeholder="Username"
            required
          /> <br>

          <label for="Email">Email:</label>
          <input
            class="text"
            v-model="Email"
            type="text"
            id="Email"
            name="Email"
            placeholder="Email"
            required
            /> <br>

            <label for="mobile">Mobile:</label>
          <input
            class="text"
            v-model="Mobile"
            type="text"
            id="mobile"
            name="mobile"
            placeholder="mobile"
            required
          /> <br>

          

          <label for="Password">Password:</label>
          <input
            class="text"
            v-model="Password"
            type="text"
            id="Password"
            name="Password"
            placeholder="Password"
            required
          /> <br>
        <button type="submit" class="btn btn-primary"> Register </button>
     </form>
     </div>
    </div>
</template>


<script>

import axios from "@/axios"
export default {
    name: "PManagerSignUP",
    data(){
      return {
      Username:"",
      Email:"",
      Mobile:"",
      Password:""
    }
  },
  methods: {
    async Signup(){
        try{
             const data={
                        Username:this.Username,
                        Password:this.Password,
                        Email:this.Email,
                        Mobile:this.Mobile,
                        };
        const output=await axios.post("/ManagerSignup",data)
        console.log("response data",output)
        alert(" Your Data have successfully recorded, Contact Admin for Role Approval")
        this.$router.push("/PManagerLogin");
      } catch(error)
      {
        console.error("Error",error)
        this.$router.push("/ErrorPage");
      }
    }
  },
}
</script>

