<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:rgb(120, 220, 116);padding-bottom:200px;height:100%;border:3px solid black">
 
 <div class="container" style="text-align:center;border-style:outset;background-color:rgb(121, 222, 124);padding-bottom:200px;height:100%;border:3px solid black">
 
  <div class="container" style="width: 80%; float:center; padding-top:15px;text-align:center "> 
  <h1><p class="text-capitalize" > Update user order :{{ product_name }} </p></h1>
  </div>
  <router-link to="/" style="padding-right:15px;" class="btn btn-primary" role="button"> Home </router-link>
  <router-link :to="{name:'AdminProductDatabase', params:{'username':username }}"  class="btn btn-primary" role="button"> Admin </router-link>
  <router-link :to="{name:'AdminLogin', params:{'username':username }}"  class="btn btn-primary" role="button"> Home </router-link>
        
  
  <div class="container" style="border-style:inset;" >  
    <form @submit.prevent="add" >
          
          <label for="Quntity">category</label>
          <input
            class="text"
            v-model="category"
            type="text"
            id="category"
            name="category"
            placeholder="category"
            required
          /><br>

          <label for="Quntity">product_name</label>
          <input
            class="text"
            v-model="product_name"
            type="text"
            id="product_name"
            name="product_name"
            placeholder="product_name"
            required
          /><br>

          <label for="Quntity">rate</label>
          <input
            class="text"
            v-model="rate"
            type="text"
            id="rate"
            name="rate"
            placeholder="rate"
            required
          /><br>

          <label for="Quntity">unit</label>
          <input
            class="text"
            v-model="unit"
            type="text"
            id="unit"
            name="unit"
            placeholder="unit"
            required
          /><br>
          
          <label for="Quntity">Avialble Quntity:</label>
          <input
            class="text"
            v-model="quantity"
            type="text"
            id="quantity"
            name="quantity"
            placeholder="quantity"
            required
          /><br>
          <button type="submit">Update</button>
        </form>
  </div>
  </div>
 </div>
</template>

<script>
import axios from "@/axios"
// @ means src dir
export default {
    name:'add_category',
    data(){
      return {
        username:"",
        category:"",
        product_name:"",
        rate:"",
        unit:"",
        quantity:""
      }
    },
    mounted(){
    this.username = this.$route.params.username;
    },
    methods: {
      async add(){
        try{
             const data={
                        "order_volumne":this.quantity,
                        "unit":this.unit,
                        "rate":this.rate,
                        "category":this.category,
                        "product_name":this.product_name
                        };
        await axios.post("/add__new_product_by_admin",data)
        //  go to /product an use mount to access params
        this.$router.push({
          name:'Category_Analysis',
          params:{
            "username":this.username
                 }
            }
          );
      } catch(error)
      {
        console.error("Error",error)
        this.$router.push("/UserSignUp");
      }
    }
  }
}
</script>