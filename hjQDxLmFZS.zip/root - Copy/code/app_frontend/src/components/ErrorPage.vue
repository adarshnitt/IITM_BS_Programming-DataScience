<template>
  <div class="container" style="text-align:center;border-style:outset;background-color:rgb(245, 96, 96);padding-bottom:200px;height:100%;border:3px solid black">
 
    <div class="position-absolute top-30 start-50" style="padding-top:15px;text-align:center ">
  <div class="container"> 
      <p class="text-capitalize" >
         Sorry, Some Error Happpened....
      </p>
  </div>
  
  <div class="container"  style="padding-top:15px">
    <router-link to="/" style="padding-right:15px" class="btn btn-primary" role="button"> Home </router-link>
  </div>
</div>
</div>
</template>
export default {
    name:ErrorPage
}