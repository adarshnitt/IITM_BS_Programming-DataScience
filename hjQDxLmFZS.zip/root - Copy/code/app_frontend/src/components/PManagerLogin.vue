<template>
    <div class="container" style="text-align:center;border-style:outset;background-color:rgb(201, 230, 98);padding-bottom:200px;height:100%;border:3px solid black">
 
 <div class="container" style="text-align:center;border-style:outset;background-color:rgb(211, 235, 108);padding-bottom:200px;height:100%;border:3px solid black">
 
  <div class="container" style="width: 80%; float:center; padding-top:15px;text-align:center "> 
  <h1><p class="text-capitalize" > Manager Login </p></h1>
  </div>
  
  <router-link to="/PManagerSignUP" style="" class="btn btn-primary"  role="button"> Sign Up </router-link><br>
  <router-link to="/" style="" class="btn btn-primary"  role="button"> Home </router-link>
  <router-link to="/AdminLogin"  class="btn btn-primary" role="button">Admin login</router-link>
  
  
  <div class="container" style="border-style:inset;" >  
    <form @submit.prevent="submit">
      <label for="username">Username:</label>
          <input
            class="text"
            v-model="username"
            type="text"
            id="username"
            name="username"
            placeholder="Username"
            required
          /> <br>
          <label for="password">PassWord:</label>
          <input
            class="text"
            v-model="password"
            type="text"
            id="password"
            name="password"
            placeholder="password"
            required
          /><br>
          <button type="submit">SIGN IN</button>
        </form>
  </div>
  </div>

  <h1> Note:</h1> You could only be able to login if Admin approved your credentials
 </div>
</template>

<script>
import axios from "@/axios"
// @ means src dir
export default {
    name:'PManagerLogin',
    data(){
      return {
        username:"",
        password:""
      }
      
    },
    methods: {
      async submit(){
        try{
             const data={
                        username:this.username,
                        password:this.password
                        };
        const output=await axios.post("/ManagerLogin",data)

        
        const out0={"data":output}
        const output1= await axios.post("/security_protocol", out0)
        console.log("response data",output, output1),
        alert("JWT successfull Product manager :" +output1["data"].msg)
        //  go to /product an use mount to access params
        this.$router.push({
          name:'PManager',
          params:{
            "username":this.username
                 }
            }
          );
      } catch(error)
      {
        console.error("Error",error)
        this.$router.push("/");
      }
    }
  }
}

</script>